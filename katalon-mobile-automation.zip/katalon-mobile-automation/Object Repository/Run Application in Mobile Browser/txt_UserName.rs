<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_UserName</name>
   <tag></tag>
   <elementGuidId>2408223e-e183-4b2b-87f8-bb3c392dbc55</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt-username</value>
   </webElementProperties>
</WebElementEntity>
