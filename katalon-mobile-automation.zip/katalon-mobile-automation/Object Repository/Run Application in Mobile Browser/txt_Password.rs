<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Password</name>
   <tag></tag>
   <elementGuidId>a18188f9-9fab-462e-a097-3ef87496f1a8</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt-password</value>
   </webElementProperties>
</WebElementEntity>
