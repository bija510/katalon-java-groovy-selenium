<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_Header Alert</name>
   <tag></tag>
   <elementGuidId>e08c7ab2-d06d-4d3a-801f-5b446a995ebb</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>App/Alert Dialogs</value>
   </webElementProperties>
</WebElementEntity>
