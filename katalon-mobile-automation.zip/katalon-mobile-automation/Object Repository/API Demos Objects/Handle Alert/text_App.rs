<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_App</name>
   <tag></tag>
   <elementGuidId>d9d31a77-f2f9-4c50-b88e-af51d5b68570</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>App</value>
   </webElementProperties>
</WebElementEntity>
