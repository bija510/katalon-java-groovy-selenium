<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_Alert Dialogs</name>
   <tag></tag>
   <elementGuidId>164c65f6-a500-47ce-85b3-8de9e79f5de6</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Alert Dialogs</value>
   </webElementProperties>
</WebElementEntity>
