<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_WebView</name>
   <tag></tag>
   <elementGuidId>4c84023e-f914-4ec6-9fe5-360ad66be1f1</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>WebView</value>
   </webElementProperties>
</WebElementEntity>
