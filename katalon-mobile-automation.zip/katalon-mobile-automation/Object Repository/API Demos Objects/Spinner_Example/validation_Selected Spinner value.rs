<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>validation_Selected Spinner value</name>
   <tag></tag>
   <elementGuidId>3dd94e29-8f76-49f0-a4e1-a8c5b74b51c9</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@resource-id='io.appium.android.apis:id/spinner2']/*[@resource-id='android:id/text1']</value>
   </webElementProperties>
</WebElementEntity>
