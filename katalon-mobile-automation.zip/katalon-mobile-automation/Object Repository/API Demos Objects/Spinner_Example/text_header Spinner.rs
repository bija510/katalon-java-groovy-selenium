<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_header Spinner</name>
   <tag></tag>
   <elementGuidId>2b3ca67e-3495-4b23-8503-97c2354e828e</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Views/Spinner</value>
   </webElementProperties>
</WebElementEntity>
