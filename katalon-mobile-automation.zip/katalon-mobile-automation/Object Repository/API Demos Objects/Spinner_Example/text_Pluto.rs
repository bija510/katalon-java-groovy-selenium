<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_Pluto</name>
   <tag></tag>
   <elementGuidId>b8589eb5-66dc-4073-8596-ca23da34148e</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pluto</value>
   </webElementProperties>
</WebElementEntity>
