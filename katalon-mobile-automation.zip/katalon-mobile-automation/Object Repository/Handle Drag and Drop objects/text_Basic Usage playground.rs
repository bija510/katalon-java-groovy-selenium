<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_Basic Usage playground</name>
   <tag></tag>
   <elementGuidId>9a396eac-8568-43d3-ab3d-8db92db5214a</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Basic usage playground</value>
   </webElementProperties>
</WebElementEntity>
