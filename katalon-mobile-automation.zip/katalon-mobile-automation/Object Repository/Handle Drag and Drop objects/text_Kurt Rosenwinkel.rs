<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_Kurt Rosenwinkel</name>
   <tag></tag>
   <elementGuidId>cecfc7dd-4374-4636-9438-1a3a9698f05c</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kurt Rosenwinkel</value>
   </webElementProperties>
</WebElementEntity>
