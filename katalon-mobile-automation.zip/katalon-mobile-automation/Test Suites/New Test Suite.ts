<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>New Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>5b0de078-e9ec-4de1-b628-04de3a7f1c41</testSuiteGuid>
   <testCaseLink>
      <guid>36f61dd7-0e08-4857-a2fb-3ac682c1a743</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/For Demo/Handle Alert</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>65fa9883-7035-4c12-bc8c-d17a2fd8539e</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>cdcce961-37d6-4044-95a3-f1dc86ba8c33</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/Handle Drag and Drop</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8c451360-f994-41a6-9e94-68207c185ddb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/Handle Radio Buttons by using List</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>57ad26ed-50e0-4f1e-9e21-f7e1c86a1684</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/Handle Spinners</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8a95f1f3-e359-4fe1-9128-0c636c9ee6ab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/How to Take Screen Shot in Mobile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>323109ac-a7e1-4cdb-a828-006f2c5c1e79</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/Multi touch Actions</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ffda1945-3c66-4bfc-9abc-f7ffe8897a9b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/Pinch to Zoom In and Verify Zoom In Action</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>10534a06-1b8d-4bf2-a425-d9a36468468e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/Record and Play Back Mobile Test Case</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6c09f805-4601-4a5c-be1e-286a0c376a3a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/zScript-WIp/Scroll To Element</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8f2b96ee-0c35-4ed0-a869-2be2a5a01872</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/zScript-WIp/Swipe Horizontal Left to Right</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>599576b7-290b-4d90-9537-7675b69162a4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/zScript-WIp/Swipe Horizontal Right to Left</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cbb78219-f7cb-45d7-816d-1a71ce5a8ee1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/zScript-WIp/Swipe Vertical bottom to top</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6fcafd55-8768-43fd-8a1f-1d26261cbf3c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/zScript-WIp/Swipe Vertical top to bottom</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9a5effe9-4d95-462c-ad9b-b37598f3a066</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Android Testings/For Demo/Run Application in Mobile Browser</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
