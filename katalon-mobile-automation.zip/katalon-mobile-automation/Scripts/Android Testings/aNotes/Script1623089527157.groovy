import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/**
 * 1. Handle Alert ========================> OK [optimized & faster]
 * 2. Handle Drag and Drop ================> OK [optimized & faster]
 * 3. Handle Radio Buttons by using List ==> OK [optimized & faster]
 * 4. Handle Spinners======================> OK [optimized & faster]
 * 5. How to Take Screen Shot in Mobile====> OK [optimized & faster]
 * 6. Multi touch Actions==================> OK [optimized & faster]
 * 
 * 7. Pinch to Zoom In and Verify Zoom In Action==> OK [optimized & faster]
 * 8. Record and Play Back Mobile Test Case=======> OK [optimized & faster]
 * 9. Run Application in Mobile Browser===========> OK [optimized & faster]
 */

