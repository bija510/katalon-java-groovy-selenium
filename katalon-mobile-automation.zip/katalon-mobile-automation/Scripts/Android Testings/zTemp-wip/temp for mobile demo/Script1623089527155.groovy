import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions
import org.openqa.selenium.support.ui.Select
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


// deviceName = ['iPhone X', 'Nexus 5', 'Galaxy S5']
Map<String, String> mobileEmulation = new HashMap<>();
mobileEmulation.put("deviceName", 'iPhone 6/7/8');
ChromeOptions chromeOptions = new ChromeOptions();
chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation)
chromeOptions.addArguments("--enableDeviceFrame");

System.setProperty("webdriver.chrome.driver", DriverFactory.getChromeDriverPath())
WebDriver driver = new ChromeDriver(chromeOptions);
driver.manage().window().maximize()
String uAgent = (String) ((JavascriptExecutor) driver).executeScript("return navigator.userAgent;"); // navigator.appVersion
System.out.println("Executed Device Name:- " + uAgent.substring(13, 37));

driver.navigate().to('https://declare-ga-qa.pcctg.net/#/index')