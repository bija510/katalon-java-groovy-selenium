import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable


/***********************************
 * macOS BigSur version:- 11.4
 * Xcode Version :- 11.3.1 (11C505)
 * Device:- iPhone 11 Pro Max -13.3
 * Appium version:- 1.21.0
 * Katalon version:- 8.0.1
 * After running this are the 3 app install in the phone
 1. IntegrationAPP
 2. IntegrationTests
 3. WebdriverAgent
 ***********************************/

def path = RunConfiguration.getProjectDir() + '/Ios app/TestApp.app'

Mobile.startApplication(path, false)

Mobile.sendKeys(findTestObject('ios test object/XCUIElementTypeTextField - IntegerA'), '1')

Mobile.sendKeys(findTestObject('ios test object/XCUIElementTypeTextField - IntegerB'), '2')
